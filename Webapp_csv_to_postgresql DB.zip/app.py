# -*- coding: utf-8 -*-


import pandas as pd
import numpy as np

from flask import Flask, render_template, request, flash, jsonify, send_file
import os
import io
import base64
from flask_sqlalchemy import SQLAlchemy
import pandas as pd
from sqlalchemy import create_engine

def connect_data(data,table,parse):
    engine = create_engine(parse, echo=False)
    df = data
    table1 = ""+table+""
    df.to_sql(table1, con=engine)
    return df

app = Flask(__name__)

app.config["UPLOAD_FOLDER"] = os.getcwd()+"\\uploads"
app.secret_key = 'secret string'

parse = 'postgresql://postgres:welcome123@localhost/postgres'
#postgresql://username:password@localhost/dbname
the_data = pd.DataFrame([])


db = SQLAlchemy(app)


@app.route('/')
@app.route('/File_upload/',methods=["GET","POST"])
def File_upload():
    global the_data_temp
    global table
    the_data_temp = pd.DataFrame([])
    global the_data
    msg=""
    if request.method == 'POST':
        
        f = request.files['uploaded']
        if(f.filename== ''):
            return render_template('file_upload.html',message = "choose file and click on upload")
        else:
            f.save(os.path.join(app.config['UPLOAD_FOLDER'],f.filename))
            the_data_temp = pd.read_csv(os.path.join(app.config['UPLOAD_FOLDER'],f.filename))
            connect_data(the_data_temp,request.form['pname'],parse)
        return render_template('file_upload.html', message="Uploaded input data!!!!!!!!")
    return render_template('file_upload.html', message="Upload input data")

    

if __name__=='__main__':
    app.run()

